# ElimuTrack — CBC School Management System

A complete, role-based school management system for the Competency-Based Curriculum (CBC): learner records, staff management, learning areas (subjects) with teacher assignment, assessments & score entry, attendance, reports & report cards, a dedicated parent portal, and a modern role-specific dashboard for every user type.

## Tech Stack

- **Backend:** Node.js + Express, PostgreSQL (via `pg`), JWT auth, bcrypt password hashing
- **Frontend:** Vanilla JS SPA (no build step) + Chart.js + Font Awesome — static files served by Express
- **PDF:** jsPDF (bundled locally, no CDN dependency at runtime except Chart.js/Font Awesome CDNs in `dashboard.html`)

## Quick Start (local)

Prerequisites: Node.js ≥ 18, PostgreSQL ≥ 13 running locally.

```bash
# 1. Create the database
createdb elimutrack

# 2. Configure environment
cp .env.example .env
#    → set DATABASE_URL and a strong JWT_SECRET

# 3. Install + run
npm install
npm start
```

Open `http://localhost:8080` — the server creates all tables, runs migrations, and seeds default data automatically on first boot.

### Seeded demo accounts (first boot only)

| Email | Password | Role |
|---|---|---|
| `admin@school.com` | `admin123` | Admin |
| `hoi@school.com` | `hoi123` | Head of Institution |
| `exam@school.com` | `exam123` | Exam Officer |
| `chair@school.com` | `chair123` | Exam Chair |
| `deputy@school.com` | `deputy123` | Deputy HOI |
| `snr@school.com` | `snr123` | Senior Teacher |
| `ct@school.com` | `class123` | Class Teacher |
| `st@school.com` | `subj123` | Subject Teacher |

**Change these passwords immediately after first login** (Settings → Users → Reset password).

## Role-Based Dashboards

Each role gets a dedicated dashboard on login:

- **Admin** — students/teachers/fees/attendance KPIs, enrollment donut, monthly summary, fee status, recent activity, system alerts
- **HOI** — student/teacher/class/assessment KPIs, exam performance (CBC/JSS tabs), finance, teacher analytics, compliance, announcements, alerts
- **Exam Officer / Chair** — assessment totals, approvals, validation queue, score-entry progress, performance analysis, reports, activity log
- **Teacher / Class / Subject teacher** — their own class scope: today's schedule, attendance, assignments to grade, submissions, class performance, announcements
- **Parent** — dedicated mobile-first portal: child profile, attendance calendar, exam results + professional report card (PDF), fees & payments, messages & alerts
- Other roles fall back to the original pulse dashboard.

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `PORT` | No | Server port (default `8080`) |
| `DATABASE_URL` | **Yes** | PostgreSQL connection string |
| `JWT_SECRET` | **Yes** | Token signing secret — generate with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `OPENAI_API_KEY` | No | Optional AI-feature key |
| `NODE_ENV` | No | `production` recommended |

## Mobile App (Flutter)

A Flutter client lives in [`mobile/`](mobile/README.md) — login (email/ADM, staff, parent), role-scoped dashboard, same REST API. See its README for run instructions (`flutter run --dart-define=API_BASE_URL=https://…`).

## Deployment

The client talks to the same origin it was served from (`window.location.origin`), so **no client-side config is needed** — just serve `public/` from Express and everything works.

### Option A — VPS (Ubuntu/Debian) with systemd

```bash
# 1. Install Node 18+ and PostgreSQL, then:
sudo -u postgres createdb elimutrack
sudo -u postgres psql -c "CREATE USER elimu WITH PASSWORD 'STRONG_DB_PASS';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE elimutrack TO elimu;"

# 2. Get the code
git clone <your-repo> /opt/elimutrack
cd /opt/elimutrack && npm install --omit=dev

# 3. Configure
cp .env.example .env   # set DATABASE_URL + JWT_SECRET

# 4. systemd service
sudo tee /etc/systemd/system/elimutrack.service > /dev/null <<'EOF'
[Unit]
Description=ElimuTrack School Management System
After=network.target postgresql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/elimutrack
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now elimutrack
curl -s http://127.0.0.1:8080/api/health   # expect {"ok":true,...}
```

Optionally front it with Nginx/Caddy for HTTPS and a real domain (proxy to `127.0.0.1:8080`).

### Option B — Fly.io

The repo ships with `fly.toml`, a `Dockerfile` and a `.dockerignore` — deploy in minutes:

```bash
# 0) Prereqs: install the flyctl CLI (https://fly.io/docs/flyctl/install/) and sign in
fly auth login

# 1) Provision a managed Postgres and attach it (injects DATABASE_URL)
fly postgres create --name elimutrack-db
#    (note the credentials — keep them safe)

# 2) Create the app without deploying yet (choose your region, e.g. nbo / ewr / ams)
fly launch --no-deploy --region nbo

# 3) Attach the database to the app
fly postgres attach elimutrack-db --app elimutrack

# 4) Set the secret (the server refuses to boot without a strong JWT_SECRET)
fly secrets set --app elimutrack JWT_SECRET="$(openssl rand -hex 32)"

# 5) Deploy!
fly deploy
fly open
```

- The container listens on `PORT=8080` and Fly's health check hits `GET /api/health` (boot grace period 15s).
- The DB schema + seeded demo accounts are created automatically on first boot.
- Scale to zero when idle: `fly scale count 0` (auto-start/stop are already enabled in `fly.toml`).
- Persistent data lives in Fly Postgres — `fly postgres connect -a elimutrack-db` for SQL access; back up with `fly pg dump` (see Data & Backups below).

### Option C — PaaS (Railway / Render / Heroku)

1. Push the repo (or zip-deploy).
2. Set the environment variables `DATABASE_URL` and `JWT_SECRET` (Railway/Render auto-provision PostgreSQL and inject `DATABASE_URL`).
3. Build command: `npm install` — Start command: `npm start`.
4. Done — the DB schema + seed run automatically on boot.

## Data & Backups

- All data is PostgreSQL-persisted; the client also keeps a local snapshot (localStorage) for offline resilience and resyncs on reconnect.
- Use `pg_dump` for database backups:
  ```bash
  pg_dump "$DATABASE_URL" -Fc -f elimutrack.dump
  ```

## Health & Maintenance

- `GET /api/health` — uptime, DB connectivity, version
- `npm run check` — syntax-check all JS files before deploying

## Troubleshooting

| Problem | Fix |
|---|---|
| `ECONNREFUSED` on boot | Check PostgreSQL is running and `DATABASE_URL` is correct |
| Login fails after restore | Restoring an old backup wipes `passwordHash` only if the backup lacks them — use **Settings → Backup** to export, and re-set passwords from Settings → Users if needed |
| Browser shows stale UI | Hard refresh (Ctrl+Shift+R) — versioned assets (`?v=` cache-bust) change with each release |
