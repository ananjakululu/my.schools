# ElimuTrack Mobile (Flutter)

Official Flutter client for the ElimuTrack CBC school management system.
It consumes the same REST API as the web app — login (email/ADM, staff, parent),
role-scoped data (`/api/db`), and a dashboard that mirrors the web role views.

## What's included

```
mobile/
├── pubspec.yaml                 # deps: http, shared_preferences, intl
├── lib/
│   ├── main.dart                # app entry + session restore
│   ├── theme.dart               # unified ElimuTrack palette (indigo/sky/emerald)
│   ├── services/
│   │   ├── api_client.dart      # login + /api/db client (token auth)
│   │   └── auth_store.dart      # token/session persistence
│   └── screens/
│       ├── login_screen.dart    # email/ADM · staff · parent login modes
│       └── home_shell.dart      # role dashboard shell (KPIs + quick access)
```

## Run it

```bash
# 1. Generate the platform folders (Android/iOS/web…)
cd mobile
flutter create . --platforms=android,ios

# 2. Point the app at your ElimuTrack server
flutter run --dart-define=API_BASE_URL=https://school.example.com
# (default: http://10.0.2.2:8080 — your local dev server via the Android emulator)

# 3. Sign in with a seeded account, e.g. admin@school.com / admin123
```

## API contract (server side)

| Endpoint | Body | Purpose |
|---|---|---|
| `POST /api/login` | `{email, password}` · `{loginMode:'staff', staffSurname, staffNumber, password}` · `{loginMode:'parent', studentName, studentAdm, password}` | Returns `{token, user}` |
| `GET /api/db` | `Authorization: Bearer <token>` | Role-scoped full dataset |
| `POST /api/logout` | — | Clears the session (best effort) |

## Next steps

- Add per-role screens (Assessments entry, Reports/PDFs, Attendance marking, Fees).
- Offline cache via `shared_preferences`/`sqflite`.
- Push notifications for parent alerts (attendance, results).
