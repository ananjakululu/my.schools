import 'package:flutter/material.dart';

import '../services/api_client.dart';
import '../services/auth_store.dart';
import '../theme.dart';
import 'home_shell.dart';

/// Login screen with the same three modes as the web app:
/// Email/ADM, Staff (surname + TSC/ID), and Parent (child name + ADM + PIN).
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.api});

  final ApiClient api;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _surname = TextEditingController();
  final _staffNumber = TextEditingController();
  final _childName = TextEditingController();
  final _childAdm = TextEditingController();

  String _mode = 'email'; // email | staff | parent
  bool _busy = false;
  bool _obscure = true;

  @override
  void dispose() {
    for (final c in [_email, _password, _surname, _staffNumber, _childName, _childAdm]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final body = _mode == 'email'
          ? {'email': _email.text.trim(), 'password': _password.text, 'remember': true}
          : _mode == 'staff'
              ? {'loginMode': 'staff', 'staffSurname': _surname.text.trim(), 'staffNumber': _staffNumber.text.trim(), 'password': _password.text}
              : {'loginMode': 'parent', 'studentName': _childName.text.trim(), 'studentAdm': _childAdm.text.trim(), 'password': _password.text};
      final res = await widget.api.login(body);
      final token = (res['token'] ?? res['accessToken']) as String?;
      final user = (res['user'] ?? res) as Map<String, dynamic>;
      if (token == null) throw ApiException('No token returned by the server.');
      await AuthStore.save(token, user);
      widget.api.setToken(token);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => HomeShell(api: widget.api, user: user)),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$e'), backgroundColor: AppColors.danger),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      width: 62, height: 62, alignment: Alignment.center,
                      decoration: const BoxDecoration(
                        gradient: AppColors.brandGradient,
                        borderRadius: BorderRadius.all(Radius.circular(18)),
                      ),
                      child: const Icon(Icons.school_rounded, color: Colors.white, size: 30),
                    ),
                    const SizedBox(height: 12),
                    Text('ElimuTrack', textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                    Text('CBC School Management', textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.muted, fontSize: 13)),
                    const SizedBox(height: 22),

                    // ── mode switch ──
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'email', label: Text('Email / ADM')),
                        ButtonSegment(value: 'staff', label: Text('Staff')),
                        ButtonSegment(value: 'parent', label: Text('Parent')),
                      ],
                      selected: {_mode},
                      onSelectionChanged: (s) => setState(() => _mode = s.first),
                    ),
                    const SizedBox(height: 18),

                    if (_mode == 'email') ...[
                      TextFormField(
                        controller: _email,
                        decoration: const InputDecoration(labelText: 'Email or ADM', prefixIcon: Icon(Icons.mail_outline)),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Email or ADM is required.' : null,
                      ),
                    ] else if (_mode == 'staff') ...[
                      TextFormField(
                        controller: _surname,
                        decoration: const InputDecoration(labelText: 'Surname', prefixIcon: Icon(Icons.person_outline)),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Surname is required.' : null,
                      ),
                      TextFormField(
                        controller: _staffNumber,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Staff Number (TSC / ID)', prefixIcon: Icon(Icons.badge_outlined)),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Staff number is required.' : null,
                      ),
                    ] else ...[
                      TextFormField(
                        controller: _childName,
                        decoration: const InputDecoration(labelText: 'Student Name', prefixIcon: Icon(Icons.child_care_outlined)),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Student name is required.' : null,
                      ),
                      TextFormField(
                        controller: _childAdm,
                        decoration: const InputDecoration(labelText: 'Admission Number', prefixIcon: Icon(Icons.numbers)),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Admission number is required.' : null,
                      ),
                    ],
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _password,
                      obscureText: _obscure,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        ),
                      ),
                      validator: (v) => (v == null || v.isEmpty) ? 'Password is required.' : null,
                      onFieldSubmitted: (_) => _submit(),
                    ),
                    const SizedBox(height: 20),
                    FilledButton(
                      onPressed: _busy ? null : _submit,
                      child: _busy
                          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Text('Sign In'),
                    ),
                    const SizedBox(height: 14),
                    Text('Seeded demo: admin@school.com / admin123',
                        textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 11.5)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
