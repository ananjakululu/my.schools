import 'package:flutter/material.dart';

import '../services/api_client.dart';
import '../services/auth_store.dart';
import '../theme.dart';
import 'login_screen.dart';

/// Role-aware home shell: fetches /api/db and shows a compact KPI dashboard
/// plus quick navigation, mirroring the web role dashboards.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.api, required this.user});

  final ApiClient api;
  final Map<String, dynamic> user;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  late Future<Map<String, dynamic>> _dbFuture;
  int _tab = 0;

  String get _role => (widget.user['role'] ?? 'staff').toString();

  @override
  void initState() {
    super.initState();
    _dbFuture = widget.api.fetchDb();
  }

  Future<void> _logout() async {
    await widget.api.logout();
    await AuthStore.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => LoginScreen(api: widget.api)),
      (r) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = (widget.user['name'] ?? 'User').toString();
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.school_rounded, color: Color(0xFF818CF8)),
            const SizedBox(width: 8),
            Text('ElimuTrack', style: const TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Log out',
            icon: const Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _dbFuture,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.cloud_off, size: 44, color: AppColors.danger),
                    const SizedBox(height: 10),
                    Text('${snap.error}', textAlign: TextAlign.center,
                        style: const TextStyle(color: AppColors.muted)),
                    const SizedBox(height: 14),
                    FilledButton(onPressed: () => setState(() => _dbFuture = widget.api.fetchDb()),
                        child: const Text('Retry')),
                  ],
                ),
              ),
            );
          }
          final db = snap.data!;
          final students = (db['students'] as List? ?? []).length;
          final staff = (db['staff'] as List? ?? []).length;
          final exams = (db['exams'] as List? ?? []).whereType<Map<String, dynamic>>()
              .where((e) => e['type'] == 'assessment').length;
          return RefreshIndicator(
            onRefresh: () async => setState(() => _dbFuture = widget.api.fetchDb()),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('Welcome back, $_role',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.muted)),
                Text(name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 18),
                Row(children: [
                  _kpi(context, Icons.groups_rounded, 'Learners', '$students', AppColors.primary),
                  const SizedBox(width: 10),
                  _kpi(context, Icons.badge_outlined, 'Staff', '$staff', AppColors.accent),
                  const SizedBox(width: 10),
                  _kpi(context, Icons.assignment_turned_in_rounded, 'Assessments', '$exams', AppColors.success),
                ]),
                const SizedBox(height: 18),
                _sectionTitle('Quick Access'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8, runSpacing: 8,
                  children: [
                    _quick(context, Icons.groups_outlined, 'Learners'),
                    _quick(context, Icons.assignment_outlined, 'Assessments'),
                    _quick(context, Icons.assessment_outlined, 'Reports'),
                    _quick(context, Icons.calendar_month_outlined, 'Attendance'),
                    _quick(context, Icons.attach_money_rounded, 'Finance'),
                    _quick(context, Icons.notifications_outlined, 'Alerts'),
                  ],
                ),
                const SizedBox(height: 22),
                _sectionTitle('About this build'),
                const Card(child: ListTile(
                  leading: Icon(Icons.school_outlined, color: AppColors.primary),
                  title: Text('ElimuTrack mobile client'),
                  subtitle: Text('Role-scoped dashboard · same API as the web app · v3.4.0'),
                )),
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'Assessments'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Reports'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _sectionTitle(String t) =>
      Text(t, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15));

  Widget _kpi(BuildContext context, IconData icon, String label, String value, Color color) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(height: 8),
              Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              Text(label, style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _quick(BuildContext context, IconData icon, String label) {
    return ActionChip(
      avatar: Icon(icon, size: 16, color: AppColors.primary),
      label: Text(label),
      onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$label module — coming next in the mobile client.')),
      ),
    );
  }
}
