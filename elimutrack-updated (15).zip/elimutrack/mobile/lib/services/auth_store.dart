import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Persists the auth token + session across app restarts.
class AuthStore {
  static const _kToken = 'elimutrack_token';
  static const _kUser = 'elimutrack_user';

  static Future<void> save(String token, Map<String, dynamic> user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kToken, token);
    await prefs.setString(_kUser, jsonEncode(user));
  }

  static Future<(String?, Map<String, dynamic>?)> load() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_kToken);
    final rawUser = prefs.getString(_kUser);
    Map<String, dynamic>? user;
    if (rawUser != null) {
      try {
        user = jsonDecode(rawUser) as Map<String, dynamic>;
      } catch (_) {/* ignore */}
    }
    return (token, user);
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kToken);
    await prefs.remove(_kUser);
  }
}
