import 'dart:convert';
import 'package:http/http.dart' as http;

/// Thin client for the ElimuTrack REST API.
///
/// Override the base URL at build/run time:
///   --dart-define=API_BASE_URL=https://school.example.com
/// Defaults to the local dev server.
class ApiClient {
  ApiClient({String? baseUrl})
      : baseUrl = baseUrl ?? const String.fromEnvironment(
          'API_BASE_URL',
          defaultValue: 'http://10.0.2.2:8080', // Android emulator → host
        );

  final String baseUrl;
  String? _token;

  void setToken(String? token) => _token = token;
  String? get token => _token;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  /// POST /api/login — email/ADM, staff (surname+number), or parent modes.
  Future<Map<String, dynamic>> login(Map<String, dynamic> body) async {
    final res = await http.post(
      Uri.parse('$baseUrl/api/login'),
      headers: _headers,
      body: jsonEncode(body),
    );
    final data = _decode(res);
    if (res.statusCode != 200 || data['success'] != true) {
      throw ApiException(data['message'] ?? 'Login failed (${res.statusCode}).');
    }
    return data;
  }

  /// GET /api/db — the full role-scoped dataset (students, exams, staff…).
  Future<Map<String, dynamic>> fetchDb() async {
    final res = await http.get(Uri.parse('$baseUrl/api/db'), headers: _headers);
    final data = _decode(res);
    if (res.statusCode != 200) {
      throw ApiException(data['error'] ?? 'Failed to load data (${res.statusCode}).');
    }
    return data;
  }

  /// POST /api/logout (best effort).
  Future<void> logout() async {
    try {
      await http.post(Uri.parse('$baseUrl/api/logout'), headers: _headers);
    } catch (_) {/* ignore */}
    _token = null;
  }

  Map<String, dynamic> _decode(http.Response res) {
    try {
      return jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      return {'message': 'Unexpected server response (${res.statusCode}).'};
    }
  }
}

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}
