import 'package:flutter/material.dart';

import 'screens/home_shell.dart';
import 'screens/login_screen.dart';
import 'services/api_client.dart';
import 'services/auth_store.dart';
import 'theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ElimuTrackApp());
}

class ElimuTrackApp extends StatelessWidget {
  const ElimuTrackApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ElimuTrack',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(Brightness.light),
      darkTheme: buildAppTheme(Brightness.dark),
      home: const _Bootstrap(),
    );
  }
}

/// Restores a persisted session, otherwise shows the login screen.
class _Bootstrap extends StatefulWidget {
  const _Bootstrap();

  @override
  State<_Bootstrap> createState() => _BootstrapState();
}

class _BootstrapState extends State<_Bootstrap> {
  final ApiClient _api = ApiClient();
  bool _ready = false;
  Map<String, dynamic>? _user;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    final (token, user) = await AuthStore.load();
    if (token != null && user != null) {
      _api.setToken(token);
    }
    if (mounted) {
      setState(() {
        _user = user;
        _ready = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final user = _user;
    return user != null
        ? HomeShell(api: _api, user: user)
        : LoginScreen(api: _api);
  }
}
